package com.sun.xml.bind.v2.model.runtime;

import java.lang.reflect.Type;

import com.sun.xml.bind.v2.model.core.TypeInfo;

/**
 * @author Kohsuke Kawaguchi
 */
public interface RuntimeTypeInfo extends TypeInfo<Type,Class> {
}
