
package com.sun.tools.xjc.generator.annotation.ri;

import com.sun.codemodel.JAnnotationWriter;
import com.sun.xml.bind.annotation.OverrideAnnotationOf;

public interface OverrideAnnotationOfWriter
    extends JAnnotationWriter<OverrideAnnotationOf>
{


    OverrideAnnotationOfWriter value(String value);

}
