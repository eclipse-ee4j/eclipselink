
package com.sun.xml.bind.v2.schemagen.xmlschema;

import com.sun.xml.txw2.TypedXmlWriter;

public interface ExplicitGroup
    extends Annotated, NestedParticle, Occurs, TypedXmlWriter
{


}
